/* Formatted on 28/08/2011 16:06:44 (QP5 v5.139.911.3011) */
BEGIN
   UTL_TSV.read_tsv_file ('nrg_ind_342m.tsv');
END;